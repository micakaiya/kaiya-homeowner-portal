import { User, Project, ProjectUser, ProjectUpdate, ProjectFile, Message, Payment, Milestone, Notification } from "@prisma/client"

// Extended types with relations
export type ProjectWithDetails = Project & {
  users: (ProjectUser & {
    user: User
  })[]
  updates: ProjectUpdate[]
  files: ProjectFile[]
  messages: Message[]
  payments: Payment[]
  milestones: Milestone[]
}

export type ProjectUpdateWithFiles = ProjectUpdate & {
  files: ProjectFile[]
}

export type MessageWithUsers = Message & {
  sender: User
  recipient?: User
}

export type UserWithProjects = User & {
  projects: (ProjectUser & {
    project: Project
  })[]
}

// Form types
export interface SignUpFormData {
  firstName: string
  lastName: string
  email: string
  phone?: string
  password: string
  confirmPassword: string
}

export interface SignInFormData {
  email: string
  password: string
  remember?: boolean
}

export interface ProjectFormData {
  name: string
  description?: string
  address: string
  type: string
  startDate?: string
  endDate?: string
  budget?: number
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// Dashboard types
export interface DashboardStats {
  projectProgress: number
  daysRemaining: number
  openMessages: number
  totalDocuments: number
}

export interface ProjectTimeline {
  milestones: Milestone[]
  updates: ProjectUpdateWithFiles[]
}

// File upload types
export interface FileUploadResult {
  id: string
  filename: string
  originalFilename: string
  url: string
  size: number
  mimetype: string
}