import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  Building2, 
  Calendar, 
  MessageSquare, 
  FileText,
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react'
import Link from 'next/link'

// Mock data - in real app this would come from API/database
const projectData = {
  name: "Main Street Residence Renovation",
  status: "In Progress",
  progress: 65,
  startDate: "2024-01-15",
  endDate: "2024-05-30",
  nextMilestone: "Kitchen Installation",
  team: {
    projectManager: "Sarah Johnson",
    contractor: "Mike Thompson"
  }
}

const recentUpdates = [
  {
    id: 1,
    title: "Electrical work completed",
    date: "2024-03-10",
    type: "milestone",
    description: "All electrical installations and inspections have been completed successfully."
  },
  {
    id: 2,
    title: "Plumbing inspection scheduled",
    date: "2024-03-12",
    type: "info",
    description: "City inspector will visit on March 15th for plumbing inspection."
  },
  {
    id: 3,
    title: "Kitchen appliances delivered",
    date: "2024-03-08",
    type: "update",
    description: "All kitchen appliances have been delivered and are ready for installation."
  }
]

const stats = [
  {
    name: "Project Progress",
    value: "65%",
    change: "+5%",
    changeType: "increase",
    icon: TrendingUp
  },
  {
    name: "Days Remaining",
    value: "78",
    change: "On schedule",
    changeType: "neutral",
    icon: Calendar
  },
  {
    name: "Open Messages",
    value: "3",
    change: "2 new",
    changeType: "info",
    icon: MessageSquare
  },
  {
    name: "Documents",
    value: "24",
    change: "3 new",
    changeType: "info",
    icon: FileText
  }
]

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, John!</h1>
          <p className="text-gray-600 mt-1">Here's what's happening with your project today.</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/messages">
            <MessageSquare className="mr-2 h-4 w-4" />
            Send Message
          </Link>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.name}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className={`text-sm ${
                    stat.changeType === 'increase' ? 'text-green-600' :
                    stat.changeType === 'info' ? 'text-blue-600' : 'text-gray-600'
                  }`}>
                    {stat.change}
                  </p>
                </div>
                <stat.icon className="h-8 w-8 text-kaiya-600" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Project Overview */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <Building2 className="mr-2 h-5 w-5 text-kaiya-600" />
                    {projectData.name}
                  </CardTitle>
                  <CardDescription>
                    Started {new Date(projectData.startDate).toLocaleDateString()} • 
                    Expected completion {new Date(projectData.endDate).toLocaleDateString()}
                  </CardDescription>
                </div>
                <div className="text-right">
                  <div className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-kaiya-100 text-kaiya-800">
                    {projectData.status}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Progress Bar */}
              <div>
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Overall Progress</span>
                  <span>{projectData.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-kaiya-600 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${projectData.progress}%` }}
                  />
                </div>
              </div>

              {/* Next Milestone */}
              <div className="flex items-center justify-between p-4 bg-kaiya-50 rounded-lg">
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-kaiya-600 mr-3" />
                  <div>
                    <p className="font-medium text-gray-900">Next Milestone</p>
                    <p className="text-sm text-gray-600">{projectData.nextMilestone}</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  View Timeline
                </Button>
              </div>

              {/* Team */}
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Your Team</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-kaiya-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-kaiya-700">SJ</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{projectData.team.projectManager}</p>
                      <p className="text-xs text-gray-600">Project Manager</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-kaiya-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-kaiya-700">MT</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{projectData.team.contractor}</p>
                      <p className="text-xs text-gray-600">Lead Contractor</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Updates */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Recent Updates</CardTitle>
              <CardDescription>Latest news from your project</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentUpdates.map((update) => (
                <div key={update.id} className="flex space-x-3">
                  <div className="flex-shrink-0">
                    {update.type === 'milestone' && (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    )}
                    {update.type === 'info' && (
                      <AlertCircle className="h-5 w-5 text-blue-500" />
                    )}
                    {update.type === 'update' && (
                      <Clock className="h-5 w-5 text-kaiya-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{update.title}</p>
                    <p className="text-xs text-gray-600 mb-1">
                      {new Date(update.date).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-gray-600">{update.description}</p>
                  </div>
                </div>
              ))}
              <div className="pt-4">
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <Link href="/dashboard/timeline">View All Updates</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start" variant="outline" asChild>
                <Link href="/dashboard/messages">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Send a Message
                </Link>
              </Button>
              <Button className="w-full justify-start" variant="outline" asChild>
                <Link href="/dashboard/documents">
                  <FileText className="mr-2 h-4 w-4" />
                  View Documents
                </Link>
              </Button>
              <Button className="w-full justify-start" variant="outline" asChild>
                <Link href="/dashboard/timeline">
                  <Calendar className="mr-2 h-4 w-4" />
                  Check Timeline
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}