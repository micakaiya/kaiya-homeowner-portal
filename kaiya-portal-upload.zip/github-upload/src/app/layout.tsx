import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Kaiya Construction - Homeowner Portal',
  description: 'Your trusted partner throughout the construction journey and beyond.',
  keywords: 'construction, homeowner portal, project management, Kaiya Construction',
  authors: [{ name: 'Kaiya Construction', url: 'https://kaiya.build' }],
  creator: 'Kaiya Construction',
  publisher: 'Kaiya Construction',
  metadataBase: new URL('https://portal.kaiya.build'),
  openGraph: {
    title: 'Kaiya Construction - Homeowner Portal',
    description: 'Your trusted partner throughout the construction journey and beyond.',
    url: 'https://portal.kaiya.build',
    siteName: 'Kaiya Construction Portal',
    locale: 'en_US',
    type: 'website',
  },
  robots: {
    index: false, // Private portal
    follow: false,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen bg-background">
          {children}
        </div>
      </body>
    </html>
  )
}