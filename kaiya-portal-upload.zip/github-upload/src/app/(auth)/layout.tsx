import { Building2 } from 'lucide-react'
import Link from 'next/link'

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-kaiya-600 to-kaiya-700 text-white relative overflow-hidden">
        <div className="flex flex-col justify-center px-12 relative z-10">
          <div className="flex items-center mb-8">
            <Building2 className="h-12 w-12 mr-4" />
            <div>
              <h1 className="text-3xl font-bold">Kaiya Construction</h1>
              <p className="text-kaiya-100">Homeowner Portal</p>
            </div>
          </div>
          <div className="max-w-md">
            <h2 className="text-4xl font-bold mb-6">
              Your Construction Journey Starts Here
            </h2>
            <p className="text-lg text-kaiya-100 mb-8">
              Stay connected with your project from planning to completion. 
              Get real-time updates, communicate with your team, and manage everything in one place.
            </p>
            <div className="space-y-4">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-3" />
                <span>Real-time project updates</span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-3" />
                <span>Direct team communication</span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-3" />
                <span>Secure document management</span>
              </div>
            </div>
          </div>
        </div>
        {/* Background pattern */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.1"%3E%3Ccircle cx="7" cy="7" r="1"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20" />
      </div>

      {/* Right side - Auth Form */}
      <div className="flex-1 flex flex-col justify-center px-4 sm:px-6 lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm lg:w-96">
          <div className="lg:hidden flex items-center justify-center mb-8">
            <Building2 className="h-8 w-8 text-kaiya-600 mr-2" />
            <div>
              <h1 className="text-xl font-bold text-gray-900">Kaiya Construction</h1>
              <p className="text-sm text-gray-600">Homeowner Portal</p>
            </div>
          </div>
          {children}
          <div className="mt-8 text-center">
            <Link 
              href="/" 
              className="text-sm text-gray-600 hover:text-kaiya-600 transition-colors"
            >
              ← Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}