export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded"></div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Kaiya Construction</h1>
                <p className="text-sm text-gray-600">Homeowner Portal</p>
              </div>
            </div>
            <div className="flex space-x-4">
              <a href="/auth/signin" className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                Sign In
              </a>
              <a href="/auth/signup" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                Get Started
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Your Construction Journey, <br />
            <span className="text-blue-600">Simplified</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Stay connected with your construction project from planning to completion and beyond. 
            Get real-time updates, communicate directly with your team, and manage everything in one place.
          </p>
          <div className="flex justify-center space-x-4">
            <a href="/auth/signup" className="px-6 py-3 bg-blue-600 text-white rounded-lg text-lg hover:bg-blue-700">
              Start Your Project
            </a>
            <a href="/auth/signin" className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-lg text-lg hover:bg-blue-50">
              Access Your Portal
            </a>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Everything You Need in One Place
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our portal provides comprehensive tools to keep you informed and engaged 
              throughout your construction journey.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-300 transition-colors">
              <div className="w-10 h-10 bg-blue-600 rounded mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Project Timeline</h3>
              <p className="text-gray-600">
                Track milestones, deadlines, and progress with interactive timeline views.
              </p>
            </div>

            <div className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-300 transition-colors">
              <div className="w-10 h-10 bg-blue-600 rounded mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Direct Communication</h3>
              <p className="text-gray-600">
                Chat directly with your construction team, ask questions, and get instant updates.
              </p>
            </div>

            <div className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-300 transition-colors">
              <div className="w-10 h-10 bg-blue-600 rounded mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Document Management</h3>
              <p className="text-gray-600">
                Access contracts, permits, warranties, and project photos all in one secure location.
              </p>
            </div>

            <div className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-300 transition-colors">
              <div className="w-10 h-10 bg-blue-600 rounded mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Team Collaboration</h3>
              <p className="text-gray-600">
                Connect with architects, contractors, and specialists working on your project.
              </p>
            </div>

            <div className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-300 transition-colors">
              <div className="w-10 h-10 bg-blue-600 rounded mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Secure & Private</h3>
              <p className="text-gray-600">
                Your project information is protected with enterprise-grade security and privacy.
              </p>
            </div>

            <div className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-300 transition-colors">
              <div className="w-10 h-10 bg-blue-600 rounded mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Ongoing Support</h3>
              <p className="text-gray-600">
                Access maintenance schedules, warranty information, and post-completion support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join homeowners who trust Kaiya Construction for their building projects.
          </p>
          <a href="/auth/signup" className="px-6 py-3 bg-white text-blue-600 rounded-lg text-lg font-semibold hover:bg-gray-100">
            Create Your Account
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-blue-600 rounded"></div>
              <span className="font-semibold">Kaiya Construction</span>
            </div>
            <p className="text-sm text-gray-600">
              © 2026 Kaiya Construction Ltd. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}